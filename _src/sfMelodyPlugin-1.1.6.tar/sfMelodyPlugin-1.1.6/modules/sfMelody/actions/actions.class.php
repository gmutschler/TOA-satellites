<?php
require_once(dirname(__FILE__).'/../lib/BasesfMelodyActions.class.php');

/**
 * Actions class for Melody
 *
 * @author Maxime Picaud
 * @since 29 août 2010
 */
class sfMelodyActions extends BasesfMelodyActions
{
}